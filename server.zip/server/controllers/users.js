import Users from "../models/Users.js";
const db = "test";
import jwt from "jsonwebtoken";

export const getUsers = async (req, res) => {
  try {
    const users = await Users.find();

    res.send(users);
  } catch (err) {
    res.send({ message: "Connection to the server error, please try again" });
  }
};

export const saveUser = async (req, res) => {
  const { email, username, tagline, password, avatar } = req.body;
  const findUser = Users.findOne({ email });
  if (!findUser) {
    const user = new Users({
      email,
      username,
      avatar,
      tagline,
      password,
    });
    try {
      await user.save();
      res.json({ message: "User Saved", status: 200 });
    } catch (err) {
      res.send({ message: err });
    }
  } else {
    res.send({ message: `${email} has been already used` });
  }
};

export const handleSignIn = async (req, res) => {
  const secretKey = process.env.SECRET_KEY;
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      res.send({ message: "username and password are required" });
    } else {
      const user = await Users.findOne({ username, password });
      if (user) {
        await Users.updateOne(
          { username: user.username },
          { $set: { loggedin: true } }
        );
        let userEmail = user.email;
        const token = jwt.sign({ userEmail }, secretKey, {
          expiresIn: "5m",
        });

        return res.json({ status: true, token, user: user });
      } else {
        return res.send({ message: "invallid username or password" });
      }
    }
  } catch (err) {
    res.send({ message: err.message });
  }
};

export const handleEmailLogin = async (req, res) => {
  const secretKey = process.env.SECRET_KEY;
  try {
    const { email } = req.body;
    const user = await Users.findOne({ email });
    if (user) {
      await Users.updateOne(
        { email: user.email },
        { $set: { loggedin: true } }
      );
      const token = jwt.sign({ email }, secretKey, {
        expiresIn: "5m",
      });
      return res.json({ status: true, token, user: user });
    } else {
      return res.send({ message: "Sorry this email doesn't exist" });
    }
  } catch (err) {
    res.send({ error: err.message });
  }
};

export const sendMessage = async (req, res) => {
  res.send("Message from server");
};

// // yaAyvvXPo7PQOH8T
// // mongodb+srv://rest-api:<password>@cluster0.7yo8ti1.mongodb.net/
