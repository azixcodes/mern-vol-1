import mongoose from "mongoose";

const chatSchema = mongoose.Schema({
  
});
export default mongoose.model("chat", chatSchema);
